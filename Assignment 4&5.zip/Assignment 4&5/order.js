
const product =[
    {
        id: 1,
        image: 'download.jpeg',
        title: 'Seafood',
        price: 150,
    },

    {
        id: 2,
        image: 'images.jpeg',
        title: 'Fruits',
        price: 25,
    }
];
const  categories = [...new Set(product.map((item)=>
{return item}))]
let i=0;
document.getElementById('root').innerHTML = categories.map((item)=> 
{
    var{image, title, price} = item;
    return(
        "<div class='box'>
            <div class='img-box'>
                <img class='images' src=${image}></img>
                </div>
            <div class='bottom'>
                <P></P>
            
            
            "
      
    )
})